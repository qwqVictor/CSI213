/**
 * Driver class for testing purpose only
 * 
 * @author Huang Kaisheng (2020215138@stu.cqupt.edu.cn)
 * @version 1.0
 */
public class Driver {

	public static void main(String[] args) {
		Helper.start(args.length > 0 && args[0].compareTo("tree") == 0);
	}
}
