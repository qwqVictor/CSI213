/**
 * @author Huang Kaisheng (2020215138@stu.cqupt.edu.cn)
 * @version 1.0
 */
public class TreeException extends RuntimeException {
	public TreeException(String message) {
		super("TreeException: " + message);
	}
} 
