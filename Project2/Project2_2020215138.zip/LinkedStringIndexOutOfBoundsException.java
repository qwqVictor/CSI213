public class LinkedStringIndexOutOfBoundsException extends IndexOutOfBoundsException {
    public LinkedStringIndexOutOfBoundsException() {
        super();
    }
}
